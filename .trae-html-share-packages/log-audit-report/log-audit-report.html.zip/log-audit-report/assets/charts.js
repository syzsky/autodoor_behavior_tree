// assets/charts.js
(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  // --- Chart 1: debug_print 调用点按文件分布 ---
  var fileData = [
    { name: 'nodes.py', value: 37 },
    { name: 'editor.py', value: 21 },
    { name: 'property.py', value: 20 },
    { name: 'context.py', value: 18 },
    { name: 'app.py', value: 16 },
    { name: 'mouse.py', value: 15 },
    { name: 'input_controller_factory.py', value: 14 },
    { name: 'version_checker.py', value: 11 },
    { name: 'engine.py', value: 10 },
    { name: 'resource_service.py', value: 7 },
    { name: 'message_bus.py', value: 6 },
    { name: 'canvas.py', value: 6 },
    { name: 'log_manager.py', value: 5 },
    { name: 'ui_dispatcher.py', value: 4 },
    { name: 'alarm.py', value: 3 },
    { name: 'settings_manager.py', value: 3 },
    { name: '其他 9 个文件', value: 11 }
  ];

  var chart1 = echarts.init(document.getElementById('chart-dist'), null, { renderer: 'svg' });
  chart1.setOption({
    animation: false,
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, appendToBody: true },
    grid: { left: 20, right: 40, top: 20, bottom: 10, containLabel: true },
    xAxis: {
      type: 'value',
      name: '调用点数',
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted },
      splitLine: { lineStyle: { color: rule } }
    },
    yAxis: {
      type: 'category',
      data: fileData.map(function(d) { return d.name; }).reverse(),
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: ink, fontSize: 12 }
    },
    series: [{
      type: 'bar',
      data: fileData.map(function(d) { return d.value; }).reverse(),
      itemStyle: {
        color: function(params) {
          var idx = fileData.length - 1 - params.dataIndex;
          return idx < 5 ? accent : (idx < 10 ? accent + '99' : muted);
        },
        borderRadius: [0, 4, 4, 0]
      },
      label: { show: true, position: 'right', color: ink, fontSize: 12 }
    }]
  });
  window.addEventListener('resize', function() { chart1.resize(); });

  // --- Chart 2: 分类占比（按建议动作） ---
  var chart2 = echarts.init(document.getElementById('chart-cat'), null, { renderer: 'svg' });
  chart2.setOption({
    animation: false,
    tooltip: { trigger: 'item', appendToBody: true },
    legend: { bottom: 0, textStyle: { color: ink } },
    series: [{
      type: 'pie',
      radius: ['42%', '68%'],
      center: ['50%', '45%'],
      avoidLabelOverlap: true,
      itemStyle: { borderRadius: 6, borderColor: bg2, borderWidth: 2 },
      label: { color: ink, fontSize: 12 },
      data: [
        { name: '保留（WARN/ERROR/INFO）', value: 90, itemStyle: { color: '#16a34a' } },
        { name: '降级 DEBUG（默认不输出）', value: 104, itemStyle: { color: accent } },
        { name: '直接移除（一次性调试）', value: 17, itemStyle: { color: '#dc2626' } }
      ]
    }]
  });
  window.addEventListener('resize', function() { chart2.resize(); });
})();
